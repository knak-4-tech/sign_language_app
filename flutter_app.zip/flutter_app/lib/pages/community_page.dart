 
import 'package:flutter/material.dart';

class CommunityPage extends StatelessWidget {
  const CommunityPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.forum, size: 100, color: Colors.orange),
          const SizedBox(height: 20),
          const Text('Community Forum Coming Soon!', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
