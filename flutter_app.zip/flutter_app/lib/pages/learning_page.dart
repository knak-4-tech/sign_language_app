 
import 'package:flutter/material.dart';

class LearningPage extends StatelessWidget {
  const LearningPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.school, size: 100, color: Colors.green),
          const SizedBox(height: 20),
          const Text('Learning Modules Coming Soon!', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
