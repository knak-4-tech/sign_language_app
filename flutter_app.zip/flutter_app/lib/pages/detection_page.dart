 
import 'package:flutter/material.dart';

class DetectionPage extends StatelessWidget {
  const DetectionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.camera, size: 100, color: Colors.blue),
          const SizedBox(height: 20),
          const Text('Sign Detection Coming Soon!', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
