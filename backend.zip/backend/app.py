from fastapi import FastAPI, WebSocket
import cv2
import numpy as np
import tensorflow as tf
import base64

app = FastAPI()

# Load pre-trained ASL, BSL, ISL models (Ensure models exist in "models" folder)
asl_model = tf.keras.models.load_model("models/asl_model.h5")
bsl_model = tf.keras.models.load_model("models/bsl_model.h5")
isl_model = tf.keras.models.load_model("models/isl_model.h5")

# Function to preprocess frame before passing it to the model
def preprocess_frame(frame):
    img = cv2.resize(frame, (64, 64))  # Resize to model input size
    img = img / 255.0  # Normalize
    img = np.expand_dims(img, axis=0)  # Add batch dimension
    return img

# Select appropriate model based on mode
def get_model(mode):
    return {"ASL": asl_model, "BSL": bsl_model, "ISL": isl_model}.get(mode, None)

# WebSocket endpoint for real-time processing
@app.websocket("/ws/{mode}")
async def websocket_endpoint(websocket: WebSocket, mode: str):
    await websocket.accept()
    model = get_model(mode)
    
    if model is None:
        await websocket.send_text("Invalid mode. Choose ASL, BSL, or ISL.")
        await websocket.close()
        return
    
    while True:
        try:
            data = await websocket.receive_text()
            frame_data = base64.b64decode(data)
            np_arr = np.frombuffer(frame_data, np.uint8)
            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            processed_frame = preprocess_frame(frame)
            prediction = model.predict(processed_frame)
            predicted_class = np.argmax(prediction)

            # Send the predicted class back to the frontend
            await websocket.send_text(f"Prediction: {predicted_class}")
        except Exception as e:
            print(f"Error: {e}")
            await websocket.close()
            break

# Run FastAPI Server
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
