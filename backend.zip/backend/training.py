import argparse
import json
import logging
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from main import ASLTransformer

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def train(asl_alphabet_dir, config):
    try:
        # Load preprocessed data
        logging.info("Loading preprocessed data...")
        data = torch.load(config["preprocessed_data_path"])
        landmarks = data["landmarks"]
        labels = data["labels"]

        # Combine landmarks and labels into a dataset
        dataset = [(landmarks[i], labels[i]) for i in range(len(labels))]

        # Split into train and validation sets
        train_size = int(0.8 * len(dataset))
        val_size = len(dataset) - train_size
        train_dataset, val_dataset = random_split(dataset, [train_size, val_size])
        
        train_loader = DataLoader(train_dataset, batch_size=config["batch_size"], shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=config["batch_size"])

        # Initialize the model
        logging.info("Initializing the model...")
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = ASLTransformer(
            input_dim=config["input_dim"], 
            d_model=config["d_model"], 
            nhead=config["nhead"], 
            num_encoder_layers=config["num_encoder_layers"],
            num_decoder_layers=config["num_decoder_layers"], 
            vocab_size=config["vocab_size"], 
            max_phrase_length=1  # Set to 1 for static image processing
        ).to(device)
        
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"])
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=config["scheduler_step_size"], gamma=config["scheduler_gamma"])
        
        # Training loop
        best_val_loss = float('inf')  # Initialize best validation loss
        for epoch in range(config["epochs"]):
            logging.info(f"Starting epoch {epoch+1}/{config['epochs']}...")
            model.train()
            train_loss = 0.0  # Track training loss for the epoch
            for inputs, labels in train_loader:
                inputs, labels = inputs.to(device), labels.to(device)  
                
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                
                train_loss += loss.item()
            
            train_loss /= len(train_loader)  # Average training loss
            print(f"Epoch {epoch+1}/{config['epochs']}, Training Loss: {train_loss:.4f}")
            logging.info(f"Epoch {epoch+1}/{config['epochs']}, Training Loss: {train_loss:.4f}")
            
            # Validation loop
            model.eval()
            val_loss = 0.0
            with torch.no_grad():
                for inputs, labels in val_loader:
                    inputs, labels = inputs.to(device), labels.to(device)
                    outputs = model(inputs)
                    loss = criterion(outputs, labels)
                    val_loss += loss.item()
            
            val_loss /= len(val_loader)  # Average validation loss
            print(f"Epoch {epoch+1}/{config['epochs']}, Validation Loss: {val_loss:.4f}")
            logging.info(f"Epoch {epoch+1}/{config['epochs']}, Validation Loss: {val_loss:.4f}")
            
            # Step the scheduler
            scheduler.step()
            
            # Save the model if validation loss improves
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                torch.save(model.state_dict(), config["model_save_path"])
                print(f"Model saved with Validation Loss: {best_val_loss:.4f}")
                logging.info(f"Model saved with Validation Loss: {best_val_loss:.4f}")
    except Exception as e:
        logging.error(f"An error occurred during training: {e}")
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    try:
        # Load default configuration from config.json
        with open("config.json", "r") as config_file:
            config = json.load(config_file)

        # Define command-line arguments
        parser = argparse.ArgumentParser(description="Train the ASL Transformer model.")
        parser.add_argument("--input_dim", type=int, help="Input dimension of the model.")
        parser.add_argument("--d_model", type=int, help="Dimension of the model.")
        parser.add_argument("--nhead", type=int, help="Number of attention heads.")
        parser.add_argument("--num_encoder_layers", type=int, help="Number of encoder layers.")
        parser.add_argument("--num_decoder_layers", type=int, help="Number of decoder layers.")
        parser.add_argument("--vocab_size", type=int, help="Vocabulary size.")
        parser.add_argument("--batch_size", type=int, help="Batch size for training.")
        parser.add_argument("--epochs", type=int, help="Number of training epochs.")
        parser.add_argument("--learning_rate", type=float, help="Learning rate.")
        parser.add_argument("--scheduler_step_size", type=int, help="Step size for the learning rate scheduler.")
        parser.add_argument("--scheduler_gamma", type=float, help="Gamma for the learning rate scheduler.")
        parser.add_argument("--model_save_path", type=str, help="Path to save the trained model.")
        parser.add_argument("--preprocessed_data_path", type=str, help="Path to the preprocessed data file.")

        # Parse arguments
        args = parser.parse_args()

        # Override config.json values with command-line arguments
        for key, value in vars(args).items():
            if value is not None:
                config[key] = value

        # Start training
        train(config["asl_alphabet_dir"], config)
    except Exception as e:
        logging.error(f"An error occurred in the main block: {e}")
        print(f"An error occurred: {e}")
