import cv2
import mediapipe as mp
import numpy as np
import torch
import torch.nn as nn
from collections import deque
from torch.nn import TransformerEncoder, TransformerEncoderLayer

# MediaPipe setup
mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils

# Constants
SEQUENCE_LENGTH = 30  # Number of frames in a sequence
NUM_LANDMARKS = 543   # MediaPipe Holistic landmarks (pose, face, hands)
NUM_FEATURES = 3      # (x, y, visibility)
INPUT_DIM = NUM_LANDMARKS * NUM_FEATURES
NUM_CLASSES = 100      # Number of BSL signs to recognize
D_MODEL = 512
NHEAD = 8
NUM_LAYERS = 3

# Transformer Model
class BSLTransformer(nn.Module):
    def __init__(self):
        super(BSLTransformer, self).__init__()
        self.embedding = nn.Linear(INPUT_DIM, D_MODEL)
        self.pos_encoder = PositionalEncoding(D_MODEL)
        encoder_layers = TransformerEncoderLayer(D_MODEL, NHEAD)
        self.transformer_encoder = TransformerEncoder(encoder_layers, NUM_LAYERS)
        self.classifier = nn.Linear(D_MODEL, NUM_CLASSES)

    def forward(self, src):
        src = self.embedding(src)
        src = self.pos_encoder(src)
        output = self.transformer_encoder(src)
        output = output.mean(dim=0)  # Pool across time dimension
        return self.classifier(output)

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:x.size(0), :]

# Initialize model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = BSLTransformer().to(device)
model.load_state_dict(torch.load("bsl_transformer.pth"))
model.eval()

# Landmark extraction
def extract_landmarks(image):
    with mp_holistic.Holistic(
        static_image_mode=False,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5) as holistic:
        
        results = holistic.process(image)
        landmarks = []
        
        # Extract and combine all landmarks
        for component in [results.pose_landmarks, results.face_landmarks, 
                         results.left_hand_landmarks, results.right_hand_landmarks]:
            if component:
                for landmark in component.landmark:
                    landmarks.extend([landmark.x, landmark.y, landmark.visibility])
            else:
                landmarks.extend([0.0]*3* (NUM_LANDMARKS//4))  # Padding for missing components
        
        return np.array(landmarks)

# Real-time processing
frame_queue = deque(maxlen=SEQUENCE_LENGTH)

cap = cv2.VideoCapture(0)
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    # Convert and process frame
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    landmarks = extract_landmarks(image)
    frame_queue.append(landmarks)
    
    if len(frame_queue) == SEQUENCE_LENGTH:
        # Convert to tensor
        sequence = torch.FloatTensor(frame_queue).to(device)
        
        # Make prediction
        with torch.no_grad():
            output = model(sequence)
            prediction = torch.argmax(output).item()
            
        # Display prediction
        cv2.putText(frame, f"Sign: {prediction}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    cv2.imshow('BSL Recognition', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()