import numpy as np
import mediapipe as mp 
from loader import load_bsl_dataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

def preprocess_dataset(video_dir, label_file, sequence_length=30):
    # Load raw data
    videos, labels = load_bsl_dataset(video_dir, label_file)  # Implement dataset loader
    
    # Landmark extraction and cleaning
    mp_holistic = mp.solutions.holistic
    processed_sequences = []
    
    with mp_holistic.Holistic() as holistic:
        for video in videos:
            sequence = []
            for frame in video:
                results = holistic.process(frame)
                landmarks = extract_and_clean_landmarks(results)
                sequence.append(landmarks)
            
            # Handle variable-length sequences
            if len(sequence) > sequence_length:
                sequence = sequence[:sequence_length]  # Truncate
            else:
                sequence += [np.zeros_like(sequence[0])] * (sequence_length - len(sequence))  # Pad
            
            processed_sequences.append(np.array(sequence))
    
    # Normalization
    sequences = np.array(processed_sequences)
    sequences[..., :2] = sequences[..., :2] - np.mean(sequences[..., :2], axis=(0, 1, 2))  # Center coordinates
    sequences[..., :2] /= np.max(np.abs(sequences[..., :2]))  # Scale to [-1, 1]
    
    # Label encoding
    le = LabelEncoder()
    encoded_labels = le.fit_transform(labels)
    
    return train_test_split(sequences, encoded_labels, test_size=0.2)

def extract_and_clean_landmarks(results):
    # Extract and handle missing landmarks
    landmarks = []
    components = [
        results.pose_landmarks,
        results.face_landmarks,
        results.left_hand_landmarks,
        results.right_hand_landmarks
    ]
    
    for comp in components:
        if comp:
            landmarks += [[lmk.x, lmk.y, lmk.visibility] for lmk in comp.landmark]
        else:
            # Add zero-padding for missing components
            landmarks += [[0.0, 0.0, 0.0]] * (543//4)  # Holistic model component sizes
    
    # Remove NaN values
    return np.nan_to_num(landmarks).flatten()