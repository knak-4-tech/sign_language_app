import numpy as np
import mediapipe as mp
import cv2
import os
import json
import torch
from sklearn.preprocessing import LabelEncoder

def preprocess_img_data(image_dir, output_file="preprocessed_data.pt", mp_holistic=None):
    """
    Preprocess the ASL Alphabet image dataset and save the preprocessed data to a .pt file.
    """
    # Initialize MediaPipe Holistic if not provided
    if mp_holistic is None:
        mp_holistic = mp.solutions.holistic.Holistic(
            static_image_mode=True,  # Process single images
            min_detection_confidence=0.5
        )
    
    # Get list of classes (A-Z)
    classes = sorted([d for d in os.listdir(image_dir) if os.path.isdir(os.path.join(image_dir, d))])
    
    # Initialize lists for data and labels
    landmarks_list = []
    labels_list = []
    
    # Process each class
    for class_idx, class_name in enumerate(classes):
        class_dir = os.path.join(image_dir, class_name)
        image_files = [f for f in os.listdir(class_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        
        # Process each image in the class
        for img_file in image_files:
            img_path = os.path.join(class_dir, img_file)
            
            try:
                image = cv2.imread(img_path)
                if image is None:
                    raise ValueError(f"Failed to load image: {img_path}")
                # Convert image to RGB
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                
                # Extract landmarks
                results = mp_holistic.process(image)
                landmarks = extract_and_clean_landmarks(results)
                
                # Append to lists
                landmarks_list.append(landmarks)
                labels_list.append(class_idx)  # Use class index as label
            except Exception as e:
                print(f"Error processing {img_path}: {e}")
                continue
    
    # Convert to numpy arrays
    landmarks_array = np.array(landmarks_list)
    labels_array = np.array(labels_list)
    
    # Normalization
    if landmarks_array.size > 0:
        landmarks_array[..., :2] -= np.mean(landmarks_array[..., :2], axis=0)  # Center coordinates
        max_val = np.max(np.abs(landmarks_array[..., :2]))
        if max_val > 0:
            landmarks_array[..., :2] /= max_val  # Scale to [-1, 1]
    
    # Convert to PyTorch tensors
    landmarks_tensor = torch.tensor(landmarks_array, dtype=torch.float32)
    labels_tensor = torch.tensor(labels_array, dtype=torch.long)
    
    # Save preprocessed data to a .pt file
    try:
        torch.save({"landmarks": landmarks_tensor, "labels": labels_tensor}, output_file)
        print(f"Preprocessed data saved to {output_file}")
    except Exception as e:
        print(f"Error saving preprocessed data: {e}")
    
    return landmarks_tensor, labels_tensor

def extract_and_clean_landmarks(results):
    """
    Extract and clean landmarks from MediaPipe results.
    """
    landmarks = []
    components = [
        results.pose_landmarks,
        results.face_landmarks,
        results.left_hand_landmarks,
        results.right_hand_landmarks
    ]
    
    for comp in components:
        if comp and comp.landmark:
            landmarks += [[lmk.x, lmk.y, lmk.visibility] for lmk in comp.landmark]
        else:
            # Handle missing components by appending zeros
            num_landmarks = 33 if comp is results.pose_landmarks else 468 if comp is results.face_landmarks else 21
            landmarks += [[0.0, 0.0, 0.0]] * num_landmarks
    
    # Remove NaN values
    return np.nan_to_num(landmarks).flatten()

if __name__ == "__main__":

    with open("config.json", "r") as config_file:
        config = json.load(config_file)
    preprocess_img_data(config["asl_alphabet_dir"])
