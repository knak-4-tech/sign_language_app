import cv2
import mediapipe as mp
import numpy as np
import torch
import torch.nn as nn
import json
from collections import deque
from torch.nn import TransformerEncoder, TransformerEncoderLayer

# Load configuration
with open("config.json", "r") as config_file:
    config = json.load(config_file)

# Use config values
INPUT_DIM = config["input_dim"]
D_MODEL = config["d_model"]
NHEAD = config["nhead"]
NUM_LAYERS = config["num_encoder_layers"]
NUM_CLASSES = config["vocab_size"]
NUM_LANDMARKS = config["num_landmarks"]
SEQUENCE_LENGTH = 1  # Set to 1 for static image processing

# MediaPipe setup
mp_holistic = mp.solutions.holistic

# Positional Encoding
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe)

    def forward(self, x):
        pe = self.pe[:x.size(1), :].unsqueeze(0)  # Ensure alignment with batch and sequence length
        return x + pe

# Transformer Model
class ASLTransformer(nn.Module):
    def __init__(self, input_dim, d_model, nhead, num_encoder_layers, num_decoder_layers, vocab_size, max_phrase_length):
        super(ASLTransformer, self).__init__()
        self.embedding = nn.Linear(input_dim, d_model)
        self.positional_encoding = PositionalEncoding(d_model, max_phrase_length)
        encoder_layers = TransformerEncoderLayer(d_model, nhead)
        self.transformer_encoder = TransformerEncoder(encoder_layers, num_encoder_layers)
        self.classifier = nn.Linear(d_model, vocab_size)

    def forward(self, src):
        src = self.embedding(src)  # [batch_size, input_dim] -> [batch_size, d_model]
        src = self.positional_encoding(src)  # Add positional encoding
        output = self.transformer_encoder(src)  # [batch_size, seq_length, d_model]
        output = output.mean(dim=1)  # Pool across the sequence length
        return self.classifier(output)  # [batch_size, vocab_size]

# Landmark extraction
def extract_landmarks(image, holistic_processor):
    results = holistic_processor.process(image)
    landmarks = []
    for component in [results.pose_landmarks, results.face_landmarks, results.left_hand_landmarks, results.right_hand_landmarks]:
        if component:
            for landmark in component.landmark:
                landmarks.extend([landmark.x, landmark.y, landmark.visibility])
        else:
            landmarks.extend([0.0] * 3 * (NUM_LANDMARKS // 4))
    return np.array(landmarks)

# Real-time processing and prediction
def real_time_inference():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = ASLTransformer(INPUT_DIM, D_MODEL, NHEAD, NUM_LAYERS, NUM_LAYERS, NUM_CLASSES, SEQUENCE_LENGTH).to(device)
    model.load_state_dict(torch.load("models/asl_transformer.pth"))  # Load the trained model
    model.eval()

    frame_queue = deque(maxlen=SEQUENCE_LENGTH)
    holistic_processor = mp_holistic.Holistic(
        static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.5
    )

    cap = cv2.VideoCapture(0)

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Convert frame
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Extract landmarks
        landmarks = extract_landmarks(rgb_frame, holistic_processor)
        frame_queue.append(landmarks)

        if len(frame_queue) == SEQUENCE_LENGTH:
            sequence = torch.FloatTensor(frame_queue).unsqueeze(0).to(device)
            with torch.no_grad():
                output = model(sequence)
                predicted_token = torch.argmax(output).item()
            prediction = chr(predicted_token + 65)  # Convert class index to alphabet letter (A-Z)
            cv2.putText(frame, f"Prediction: {prediction}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.imshow("ASL Analyzer", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    holistic_processor.close()  # Proper cleanup of the holistic processor

if __name__ == "__main__":
    real_time_inference()
